﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using Tablas_MerchanIvan.Models;

namespace Tablas_MerchanIvan
{
    public class AplicationDbContext : DbContext
    {
        public AplicationDbContext(DbContextOptions<AplicationDbContext> options) : base(options) { }

        public DbSet<Genero> Generos { get; set; }

        public DbSet<Usuario> Usuarios { get; set; }
    
    }
}
